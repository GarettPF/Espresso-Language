package Phases;

public class Phase7 extends Phase6 {
    public void execute(Object arg, int debugLevel, int runLevel) {
    }       	
}
