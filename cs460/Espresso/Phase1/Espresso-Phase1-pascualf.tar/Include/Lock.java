class Lock {
    public static void foo(int v) { }
}
