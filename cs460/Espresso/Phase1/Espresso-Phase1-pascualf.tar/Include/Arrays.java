// This file goes in Include
public class Arrays {
    public static void fill(float[] array, float value) { }
    public static void fill(char[] array, char value) { }
}
