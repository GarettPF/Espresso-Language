class Io2 {
     public void print(byte b) { }
     public void print(short s) { }
     public void print(char c) { }
     public void print(int i) { }
     public void print(long l) { }
     public void print(float f) { }
     public void print(double d){ }
     public void print(String s){ }
     public void print(boolean b){ }
     public void println(byte b) { }
     public void println(short s){ }
     public void println(char c) { }
     public void println(int i) { }
     public void println(long l) { }
     public void println(float f){ }
     public void println(double d){ }
     public void println(String s){ }
     public void println(boolean b){ }

     public int readInt() { }
     public long readLong() { }
     public float readFloat() { }
     public double readDouble() { }
     public String readString() { }
}
