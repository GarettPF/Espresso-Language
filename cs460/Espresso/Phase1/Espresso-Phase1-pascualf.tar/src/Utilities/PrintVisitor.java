package Utilities;

import Utilities.Visitor;

public class PrintVisitor extends Visitor {
    // Intentionally left blank - content will appear in phase 2 handout
}
