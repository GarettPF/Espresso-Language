package Utilities;

public abstract class Visitor {
    // Intentionally left blank - content will appear in phase 2 handout
}
