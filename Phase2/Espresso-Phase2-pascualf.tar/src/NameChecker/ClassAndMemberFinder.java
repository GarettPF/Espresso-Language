package NameChecker;

import Utilities.Visitor;
import Utilities.SymbolTable;

public class ClassAndMemberFinder extends Visitor {
    // Intentionally left blank - content will appear in phase 3 handout
    public ClassAndMemberFinder(SymbolTable classTable, boolean debug) { 
    }
}

