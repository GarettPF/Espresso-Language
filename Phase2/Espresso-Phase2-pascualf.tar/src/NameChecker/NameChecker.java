package NameChecker;

import Utilities.Visitor;
import Utilities.SymbolTable;

public class NameChecker extends Visitor {
    // Intentionally left blank - content will appear in phase 3 handout
    public NameChecker(SymbolTable classTable, boolean debug) { 
    }
}
